var config = {
    apiKey: "AIzaSyBO-97crBWy9w_olF5qKIy2GmntKm8jkl8",
    authDomain: "namsoridentities.firebaseapp.com",
    databaseURL: "https://namsoridentities.firebaseio.com",
    projectId: "namsoridentities",
    storageBucket: "namsoridentities.appspot.com",
    messagingSenderId: "578244426610"
};

firebase.initializeApp(config);
initApp = function ()
{
    var deferred = new Promise(function (resolve, reject)
    {
      firebase.auth().onAuthStateChanged(function (user)
      {
        if (user)
        {
          user.getIdToken().then(function(accessToken)
          {
              var request = new XMLHttpRequest();
              request.open('GET', '/NamSorAPIv2/api2/json/procureKey/' + accessToken, true);
              request.onload = function ()
              {
                var data = JSON.parse(this.response);
                document.getElementById('signIn').hidden = true;
                document.getElementById('navbarDropdownPortfolio').hidden = false;
                window.api_key = data.api_key;
              }
              request.send();
              resolve("Success");
          });
        } else {
            window.api_key = null;
            document.getElementById('signIn').hidden = false;
            document.getElementById('navbarDropdownPortfolio').hidden = true;
            resolve("Success");
        }
      }, function (error)
      {
          window.api_key = null;
          console.log(error);
      });
    });
    return deferred;
};

var signOut = function ()
{
  document.getElementById('signOut').addEventListener('click', function (event) {
    firebase.auth().signOut();
    document.getElementById('signIn').hidden = false;
    document.getElementById('navbarDropdownPortfolio').hidden = true;
    });
}

var getInfo = function ()
{
    window.user_info = "unset value yet";
    var deferred = new Promise(function (resolve, reject)
    {
      firebase.auth().onAuthStateChanged(function (user)
      {
        var data = null;
        if (user)
        {
          user.getIdToken().then(function(accessToken)
          {
              var request = new XMLHttpRequest();
              request.open('GET', '/NamSorAPIv2/api2/json/userInfo/' + accessToken, true);
              request.onload = function ()
              {
                data = JSON.parse(this.response);
                window.user_info = data;
              }
              request.send();
              resolve("Success");
          });
        } else {
            window.user_info = null;
            resolve("Success");
        }
      }, function (error)
      {
          window.user_info = null;
          console.log(error);
      });
    });
    return (deferred);
};

window.addEventListener('load', function () {
    initApp();
});

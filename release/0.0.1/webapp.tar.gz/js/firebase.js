var config = {
    apiKey: "AIzaSyBO-97crBWy9w_olF5qKIy2GmntKm8jkl8",
    authDomain: "namsoridentities.firebaseapp.com",
    databaseURL: "https://namsoridentities.firebaseio.com",
    projectId: "namsoridentities",
    storageBucket: "namsoridentities.appspot.com",
    messagingSenderId: "578244426610"
};

firebase.initializeApp(config);
var fireuser;
initApp = function () {
    var deferred = new Promise(function (resolve, reject)
    {
      firebase.auth().onAuthStateChanged(function (user)
      {
        if (user)
        {
          fireuser = user;
          console.dir(fireuser);
          user.getIdToken().then(function (accessToken)
          {
              var request = new XMLHttpRequest();
              request.open('GET', '/NamSorAPIv2/api2/json/procureKey/' + accessToken, true);
              request.onload = function ()
              {
                var data = JSON.parse(this.response);
                document.getElementById('signIn').hidden = true;
                document.getElementById('navbarDropdownPortfolio').hidden = false;
                window.api_key = data.api_key;
              }
              request.send();
              resolve("okay");
          });
        } else {
            document.getElementById('signIn').hidden = false;
            document.getElementById('navbarDropdownPortfolio').hidden = true;
            window.api_key = null;
            resolve("okay");
        }
      }, function (error)
      {
          console.log(error);
      });
    });
    signOut();
    return deferred;
};

var signOut = function () {
  document.getElementById('signOut').addEventListener('click', function (event) {
    firebase.auth().signOut();
    window.api_key = null;
    document.getElementById('api_key').textContent = '';
    document.getElementById('signIn').hidden = false;
    document.getElementById('navbarDropdownPortfolio').hidden = true;
    });
}

var getInfo = function (){
  firebase.auth().currentUser.getIdToken().then(function(idToken) {
    var request = new XMLHttpRequest();
    request.open('GET', '/NamSorAPIv2/api2/json/userInfo/' + idToken, true);
    request.onload = function () {
        var data = JSON.parse(this.response);
        console.log("data " + data);
        return data;
      }
      request.send();
  }).catch(function(error) {
    console.log(error);
  });
}

window.addEventListener('load', function () {
    initApp().then(function(user)
    {
      if (user)
      {
          console.log(user.getIdToken());
      }
    });
    console.dir(fireuser);
    console.log(window.api_key);
});
